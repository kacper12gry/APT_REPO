# gui.py
import gi
import datetime
import markdown2 # Nowa zależność do konwersji Markdown na Pango

gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib, Pango

import main as backend

class VersionManagerWindow(Gtk.Window):
    MANAGER_VERSION = "0.90"

    def __init__(self):
        super().__init__(title=f"Menedżer Wersji Programu Automatyzer v{self.MANAGER_VERSION}")
        # ... (reszta inicjalizacji okna bez zmian)
        self.set_default_size(600, 400)
        self.set_border_width(10)
        self.set_position(Gtk.WindowPosition.CENTER)
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.add(vbox)
        paned = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL, position=200)
        vbox.pack_start(paned, True, True, 0)
        scrolled_window = Gtk.ScrolledWindow()
        self.version_list = Gtk.ListBox()
        self.version_list.connect("row-selected", self.on_version_selected)
        scrolled_window.add(self.version_list)
        paned.add1(scrolled_window)
        details_frame = Gtk.Frame(label="Szczegóły")
        details_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10, border_width=10)
        details_frame.add(details_box)
        self.details_label = Gtk.Label(xalign=0)
        details_box.pack_start(self.details_label, True, True, 0)
        paned.add2(details_frame)
        button_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        vbox.pack_start(button_box, False, False, 0)
        self.launch_button = Gtk.Button.new_with_label("Uruchom")
        self.set_active_button = Gtk.Button.new_with_label("Ustaw jako aktywną")
        self.download_button = Gtk.Button.new_with_label("Pobierz wersję...")
        self.update_button = Gtk.Button.new_from_icon_name("view-refresh-symbolic", Gtk.IconSize.BUTTON)
        button_box.pack_start(self.launch_button, True, True, 0)
        button_box.pack_start(self.set_active_button, True, True, 0)
        button_box.pack_start(self.download_button, True, True, 0)
        button_box.pack_end(self.update_button, False, False, 0)
        self.statusbar = Gtk.Statusbar()
        self.status_context_id = self.statusbar.get_context_id("status")
        vbox.pack_start(self.statusbar, False, False, 0)
        self.launch_button.connect("clicked", lambda w: backend.launch_app())
        self.set_active_button.connect("clicked", self.on_set_active_clicked)
        self.download_button.connect("clicked", self.on_download_clicked)
        self.update_button.connect("clicked", self.on_update_clicked)

        self.refresh_version_list()
        self.on_version_selected(self.version_list, None)

        # === NOWOŚĆ: Sprawdź aktualizację przy starcie ===
        GLib.idle_add(self.check_and_alert_for_new_version)

    # ... (funkcje refresh_version_list, on_version_selected, on_download_clicked itd. bez zmian)
    def refresh_version_list(self):
        selected_version = self.version_list.get_selected_row().version_name if self.version_list.get_selected_row() else None
        for child in list(self.version_list.get_children()): self.version_list.remove(child)
        active_version = backend.get_active_version()
        new_selected_row = None
        for version in backend.get_installed_versions():
            row = Gtk.ListBoxRow()
            hbox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
            icon = Gtk.Image.new_from_icon_name("emblem-ok-symbolic" if version == active_version else "emblem-synchronizing-symbolic", Gtk.IconSize.MENU)
            hbox.pack_start(icon, False, False, 5)
            hbox.pack_start(Gtk.Label(label=version, xalign=0), True, True, 0)
            row.add(hbox)
            row.version_name = version
            self.version_list.add(row)
            if version == selected_version: new_selected_row = row
        self.version_list.show_all()
        if new_selected_row: self.version_list.select_row(new_selected_row)
    def on_version_selected(self, listbox, row):
        is_row_selected = row is not None
        self.set_active_button.set_sensitive(is_row_selected)
        self.launch_button.set_sensitive(is_row_selected)
        if not is_row_selected:
            self.details_label.set_markup(f"<i>Wybierz wersję z listy...\n\nMenedżer wersji <b>v{self.MANAGER_VERSION}</b></i>")
            return
        version = row.version_name
        try:
            mtime = (backend.TARGET_APP_PATH / version).stat().st_mtime
            mod_time = datetime.datetime.fromtimestamp(mtime).strftime("%Y-%m-%d %H:%M:%S")
        except Exception: mod_time = "Nieznana"
        self.details_label.set_markup(f"<b>Wersja:</b> {version}\n<b>Zainstalowano:</b> {mod_time}")
    def on_download_clicked(self, widget):
        dialog = Gtk.Dialog(title="Pobierz Wersję", parent=self, flags=0)
        dialog.add_buttons(Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL, Gtk.STOCK_OK, Gtk.ResponseType.OK)
        content_area = dialog.get_content_area()
        content_area.set_spacing(10)
        content_area.pack_start(Gtk.Label(label="Wybierz wersję do pobrania z listy:"), False, False, 0)
        combo = Gtk.ComboBoxText()
        available_versions = backend.get_available_versions_from_github()
        installed_versions = backend.get_installed_versions()
        for version in available_versions:
            if version not in installed_versions:
                combo.append_text(version)
        combo.set_active(0)
        content_area.pack_start(combo, False, False, 0)
        dialog.show_all()
        response = dialog.run()
        version_tag = combo.get_active_text()
        dialog.destroy()
        if response == Gtk.ResponseType.OK and version_tag:
            self.statusbar.push(self.status_context_id, f"Pobieranie wersji {version_tag}...")
            GLib.idle_add(self.perform_specific_download, version_tag)
    def perform_specific_download(self, version_tag):
        if backend.download_specific_version(version_tag):
            self.statusbar.push(self.status_context_id, f"Pomyślnie zainstalowano {version_tag}.")
        else:
            self.statusbar.push(self.status_context_id, f"Błąd pobierania wersji {version_tag}.")
        self.refresh_version_list()
        return False
    def on_set_active_clicked(self, widget):
        selected = self.version_list.get_selected_row()
        if selected:
            backend.set_active_version(selected.version_name)
            self.refresh_version_list()
    def on_update_clicked(self, widget):
        self.statusbar.push(self.status_context_id, "Sprawdzanie najnowszej wersji...")
        GLib.idle_add(self.perform_update)
    def perform_update(self):
        new_version = backend.check_for_updates()
        if new_version:
            self.statusbar.push(self.status_context_id, f"Pomyślnie zainstalowano nową wersję {new_version}.")
        else:
            self.statusbar.push(self.status_context_id, "Brak nowych aktualizacji lub jesteś na bieżąco.")
        self.refresh_version_list()
        return False

# gui.py

    def check_and_alert_for_new_version(self):
        """Sprawdza, czy jest nowsza wersja i wyświetla sformatowany alert z listą zmian."""
        active_version = backend.get_active_version()
        latest_release = backend.get_latest_release_info()

        if not latest_release: return False
        latest_version_tag = latest_release.get("tag_name")
        if not latest_version_tag: return False

        show_alert = active_version is None or latest_version_tag > active_version

        if show_alert:
            changelog_md = latest_release.get("body", "Brak informacji o zmianach.")

            # --- PROFESJONALNA KONWERSJA MARKDOWN -> PANGO ---
            def md_to_pango(md_text):
                lines = md_text.replace('\r', '').split('\n')
                pango_lines = []
                for line in lines:
                    line = line.strip()
                    if line.startswith('### '):
                        # Nagłówek poziomu 3
                        pango_lines.append(f"<b>{line[4:]}</b>")
                    elif line.startswith('* '):
                        # Element listy
                        pango_lines.append(f"  • {line[2:]}")
                    elif line.startswith('**'):
                         # Pogrubienie w stylu **text**
                        pango_lines.append(line.replace('**', '<b>', 1).replace('**', '</b>', 1))
                    elif not line:
                        # Pusta linia jako separator
                        pango_lines.append("")
                    else:
                        pango_lines.append(line)

                return "\n".join(pango_lines)

            changelog_pango = md_to_pango(changelog_md)

            dialog = Gtk.MessageDialog(
                transient_for=self,
                modal=True,
                message_type=Gtk.MessageType.INFO,
                buttons=Gtk.ButtonsType.OK,
                text=f"Dostępna jest nowa wersja: {latest_version_tag}"
            )

            # Użyj format_secondary_markup, które poprawnie interpretuje Pango
            dialog.format_secondary_markup(
                "<b>Lista zmian:</b>\n" + GLib.markup_escape_text(changelog_pango)
            )

            dialog.set_default_size(450, 300)
            dialog.run()
            dialog.destroy()

        return False



if __name__ == "__main__":
    win = VersionManagerWindow()
    win.connect("destroy", Gtk.main_quit)
    win.show_all()
    Gtk.main()
