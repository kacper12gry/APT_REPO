import os
import subprocess
import shutil
from pathlib import Path
import requests
import tarfile
import io

# --- KONFIGURACJA ---
GITHUB_OWNER = "kacper12gry"
GITHUB_REPO = "FFmpeg_gui"
MINIMUM_SUPPORTED_VERSION = "v4.0"
# --------------------

APP_STORAGE_PATH = Path.home() / ".my_version_manager"
TARGET_APP_PATH = APP_STORAGE_PATH / "target_app"
CURRENT_SYMLINK = TARGET_APP_PATH / "current"

def _is_version_supported(version, min_version):
    try:
        v_parts = [int(p) for p in version.lstrip('v').split('.')]
        min_v_parts = [int(p) for p in min_version.lstrip('v').split('.')]
        return v_parts >= min_v_parts
    except (ValueError, TypeError):
        return False

def setup_directories():
    TARGET_APP_PATH.mkdir(parents=True, exist_ok=True)

def get_installed_versions():
    if not TARGET_APP_PATH.is_dir():
        return []
    versions = [item.name for item in TARGET_APP_PATH.iterdir() if item.is_dir() and not item.is_symlink()]
    def sort_key(v):
        try:
            return [int(p) for p in v.lstrip('v').split('.')]
        except (ValueError, AttributeError):
            return [-1]
    versions.sort(key=sort_key, reverse=True)
    return versions

def get_active_version():
    """Zwraca nazwę aktywnej wersji lub None. Obsługuje uszkodzony symlink."""
    if not CURRENT_SYMLINK.is_symlink():
        return None
    try:
        return CURRENT_SYMLINK.resolve().name
    except FileNotFoundError:
        CURRENT_SYMLINK.unlink(missing_ok=True)
        return None

def set_active_version(version):
    version_path = TARGET_APP_PATH / version
    if not version_path.is_dir():
        return False
    if CURRENT_SYMLINK.exists():
        CURRENT_SYMLINK.unlink()
    CURRENT_SYMLINK.symlink_to(version_path)
    return True

def launch_app():
    if not CURRENT_SYMLINK.is_symlink():
        return
    active_dir = CURRENT_SYMLINK.resolve()
    src_dir = active_dir / "src"
    if (src_dir / "main.py").exists():
        subprocess.Popen(["python3", "main.py"], cwd=src_dir)

def _download_and_extract_release(release_data):
    tag_name = release_data.get("tag_name")
    if not tag_name or tag_name in get_installed_versions() or not _is_version_supported(tag_name, MINIMUM_SUPPORTED_VERSION):
        return None
    tarball_url = release_data.get("tarball_url")
    if not tarball_url:
        return None

    destination_path = TARGET_APP_PATH / tag_name
    try:
        response = requests.get(tarball_url, stream=True)
        response.raise_for_status()

        # 🛡 sprawdzenie czy nie dostaliśmy JSON-a zamiast archiwum
        if response.headers.get("Content-Type", "").startswith("application/json"):
            print("Błąd: Otrzymano JSON zamiast archiwum. Możliwy limit GitHuba.")
            return None

        with tarfile.open(fileobj=io.BytesIO(response.content), mode="r:gz") as tar:
            members = tar.getmembers()
            if not members:
                raise tarfile.TarError("Archiwum jest puste.")
            root_prefix = members[0].name.split('/')[0] + '/'
            for member in members:
                if member.name.startswith(root_prefix):
                    member.name = member.name[len(root_prefix):]
                    if member.name:
                        tar.extract(member, path=destination_path)

        # 🆕 MIGRACJA settings.ini ze starej wersji (jeśli brak w nowej)
        old_settings = CURRENT_SYMLINK.resolve() / "src" / "settings.ini" if CURRENT_SYMLINK.is_symlink() else None
        new_settings = destination_path / "src" / "settings.ini"
        if old_settings and old_settings.exists() and not new_settings.exists():
            try:
                shutil.copy2(old_settings, new_settings)
                print(f"Przeniesiono settings.ini z {old_settings} do {new_settings}")
            except Exception as e:
                print(f"Nie udało się przenieść settings.ini: {e}")

        return tag_name

    except Exception as e:
        print(f"Błąd pobierania: {e}")
        if destination_path.exists():
            shutil.rmtree(destination_path, ignore_errors=True)
        return None

def get_latest_release_info():
    api_url = f"https://api.github.com/repos/{GITHUB_OWNER}/{GITHUB_REPO}/releases/latest"
    try:
        response = requests.get(api_url)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException:
        return None

def check_for_updates():
    release_info = get_latest_release_info()
    return _download_and_extract_release(release_info) if release_info else None

def download_specific_version(version_tag):
    api_url = f"https://api.github.com/repos/{GITHUB_OWNER}/{GITHUB_REPO}/releases/tags/{version_tag}"
    try:
        response = requests.get(api_url)
        response.raise_for_status()
        return _download_and_extract_release(response.json())
    except Exception:
        return None

def get_available_versions_from_github():
    api_url = f"https://api.github.com/repos/{GITHUB_OWNER}/{GITHUB_REPO}/tags"
    try:
        response = requests.get(api_url)
        response.raise_for_status()
        all_tags = [tag['name'] for tag in response.json()]
        return [tag for tag in all_tags if _is_version_supported(tag, MINIMUM_SUPPORTED_VERSION)]
    except requests.exceptions.RequestException:
        return []

setup_directories()
